gdjs.Escena_32sin_32t_237tuloCode = {};
gdjs.Escena_32sin_32t_237tuloCode.localVariables = [];
gdjs.Escena_32sin_32t_237tuloCode.GDVentanaObjects1= [];
gdjs.Escena_32sin_32t_237tuloCode.GDVentanaObjects2= [];
gdjs.Escena_32sin_32t_237tuloCode.GDLlaveObjects1= [];
gdjs.Escena_32sin_32t_237tuloCode.GDLlaveObjects2= [];
gdjs.Escena_32sin_32t_237tuloCode.GDAntorchaObjects1= [];
gdjs.Escena_32sin_32t_237tuloCode.GDAntorchaObjects2= [];
gdjs.Escena_32sin_32t_237tuloCode.GDPeligroObjects1= [];
gdjs.Escena_32sin_32t_237tuloCode.GDPeligroObjects2= [];
gdjs.Escena_32sin_32t_237tuloCode.GDBoss_9595AzulObjects1= [];
gdjs.Escena_32sin_32t_237tuloCode.GDBoss_9595AzulObjects2= [];
gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1= [];
gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects2= [];
gdjs.Escena_32sin_32t_237tuloCode.GDBoss_9595rojoObjects1= [];
gdjs.Escena_32sin_32t_237tuloCode.GDBoss_9595rojoObjects2= [];
gdjs.Escena_32sin_32t_237tuloCode.GDPinchoObjects1= [];
gdjs.Escena_32sin_32t_237tuloCode.GDPinchoObjects2= [];
gdjs.Escena_32sin_32t_237tuloCode.GDAzulejos_95951Objects1= [];
gdjs.Escena_32sin_32t_237tuloCode.GDAzulejos_95951Objects2= [];
gdjs.Escena_32sin_32t_237tuloCode.GDAzulejos_95952Objects1= [];
gdjs.Escena_32sin_32t_237tuloCode.GDAzulejos_95952Objects2= [];
gdjs.Escena_32sin_32t_237tuloCode.GDPlataformaObjects1= [];
gdjs.Escena_32sin_32t_237tuloCode.GDPlataformaObjects2= [];
gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1= [];
gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects2= [];
gdjs.Escena_32sin_32t_237tuloCode.GDAntorcha2Objects1= [];
gdjs.Escena_32sin_32t_237tuloCode.GDAntorcha2Objects2= [];


gdjs.Escena_32sin_32t_237tuloCode.asyncCallback10041364 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Escena_32sin_32t_237tuloCode.localVariables);
gdjs.Escena_32sin_32t_237tuloCode.localVariables.length = 0;
}
gdjs.Escena_32sin_32t_237tuloCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Escena_32sin_32t_237tuloCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(5), (runtimeScene) => (gdjs.Escena_32sin_32t_237tuloCode.asyncCallback10041364(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Escena_32sin_32t_237tuloCode.asyncCallback10041924 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Escena_32sin_32t_237tuloCode.localVariables);
gdjs.Escena_32sin_32t_237tuloCode.localVariables.length = 0;
}
gdjs.Escena_32sin_32t_237tuloCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Escena_32sin_32t_237tuloCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2.5), (runtimeScene) => (gdjs.Escena_32sin_32t_237tuloCode.asyncCallback10041924(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Escena_32sin_32t_237tuloCode.eventsList2 = function(runtimeScene) {

};gdjs.Escena_32sin_32t_237tuloCode.mapOfGDgdjs_9546Escena_959532sin_959532t_9595237tuloCode_9546GDMortisObjects1Objects = Hashtable.newFrom({"Mortis": gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1});
gdjs.Escena_32sin_32t_237tuloCode.mapOfGDgdjs_9546Escena_959532sin_959532t_9595237tuloCode_9546GDPinchoObjects1Objects = Hashtable.newFrom({"Pincho": gdjs.Escena_32sin_32t_237tuloCode.GDPinchoObjects1});
gdjs.Escena_32sin_32t_237tuloCode.eventsList3 = function(runtimeScene) {

};gdjs.Escena_32sin_32t_237tuloCode.mapOfGDgdjs_9546Escena_959532sin_959532t_9595237tuloCode_9546GDMortisObjects1Objects = Hashtable.newFrom({"Mortis": gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1});
gdjs.Escena_32sin_32t_237tuloCode.mapOfGDgdjs_9546Escena_959532sin_959532t_9595237tuloCode_9546GDLlaveObjects1Objects = Hashtable.newFrom({"Llave": gdjs.Escena_32sin_32t_237tuloCode.GDLlaveObjects1});
gdjs.Escena_32sin_32t_237tuloCode.eventsList4 = function(runtimeScene) {

};gdjs.Escena_32sin_32t_237tuloCode.mapOfGDgdjs_9546Escena_959532sin_959532t_9595237tuloCode_9546GDCaballoObjects1Objects = Hashtable.newFrom({"Caballo": gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1});
gdjs.Escena_32sin_32t_237tuloCode.mapOfGDgdjs_9546Escena_959532sin_959532t_9595237tuloCode_9546GDAntorchaObjects1Objects = Hashtable.newFrom({"Antorcha": gdjs.Escena_32sin_32t_237tuloCode.GDAntorchaObjects1});
gdjs.Escena_32sin_32t_237tuloCode.mapOfGDgdjs_9546Escena_959532sin_959532t_9595237tuloCode_9546GDCaballoObjects1Objects = Hashtable.newFrom({"Caballo": gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1});
gdjs.Escena_32sin_32t_237tuloCode.mapOfGDgdjs_9546Escena_959532sin_959532t_9595237tuloCode_9546GDAntorcha2Objects1Objects = Hashtable.newFrom({"Antorcha2": gdjs.Escena_32sin_32t_237tuloCode.GDAntorcha2Objects1});
gdjs.Escena_32sin_32t_237tuloCode.mapOfGDgdjs_9546Escena_959532sin_959532t_9595237tuloCode_9546GDCaballoObjects1Objects = Hashtable.newFrom({"Caballo": gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1});
gdjs.Escena_32sin_32t_237tuloCode.mapOfGDgdjs_9546Escena_959532sin_959532t_9595237tuloCode_9546GDAntorchaObjects1Objects = Hashtable.newFrom({"Antorcha": gdjs.Escena_32sin_32t_237tuloCode.GDAntorchaObjects1});
gdjs.Escena_32sin_32t_237tuloCode.mapOfGDgdjs_9546Escena_959532sin_959532t_9595237tuloCode_9546GDCaballoObjects1Objects = Hashtable.newFrom({"Caballo": gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1});
gdjs.Escena_32sin_32t_237tuloCode.mapOfGDgdjs_9546Escena_959532sin_959532t_9595237tuloCode_9546GDAntorcha2Objects1Objects = Hashtable.newFrom({"Antorcha2": gdjs.Escena_32sin_32t_237tuloCode.GDAntorcha2Objects1});
gdjs.Escena_32sin_32t_237tuloCode.mapOfGDgdjs_9546Escena_959532sin_959532t_9595237tuloCode_9546GDMortisObjects1Objects = Hashtable.newFrom({"Mortis": gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1});
gdjs.Escena_32sin_32t_237tuloCode.mapOfGDgdjs_9546Escena_959532sin_959532t_9595237tuloCode_9546GDCaballoObjects1Objects = Hashtable.newFrom({"Caballo": gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1});
gdjs.Escena_32sin_32t_237tuloCode.eventsList5 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Mortis"), gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1);
{for(var i = 0, len = gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1.length ;i < len;++i) {
    gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Mortis"), gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1);
{for(var i = 0, len = gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1.length ;i < len;++i) {
    gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Mortis"), gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1);
{for(var i = 0, len = gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1.length ;i < len;++i) {
    gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Sonido de Salto.wav", false, 60, 0.6);
}
{ //Subevents
gdjs.Escena_32sin_32t_237tuloCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Sonido de Salto.wav", false, 100, 1);
}
{ //Subevents
gdjs.Escena_32sin_32t_237tuloCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mortis"), gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1.length;i<l;++i) {
    if ( !(gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1[k] = gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1[i];
        ++k;
    }
}
gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1 */
{for(var i = 0, len = gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1.length ;i < len;++i) {
    gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1[i].getBehavior("Animation").setAnimationName("Quieto");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mortis"), gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1.length;i<l;++i) {
    if ( gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1[k] = gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1[i];
        ++k;
    }
}
gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1 */
{for(var i = 0, len = gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1.length ;i < len;++i) {
    gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1[i].getBehavior("Animation").setAnimationName("Movimiento");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mortis"), gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1.length;i<l;++i) {
    if ( gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1[i].getBehavior("PlatformerObject").isUsingControl("Right") ) {
        isConditionTrue_0 = true;
        gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1[k] = gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1[i];
        ++k;
    }
}
gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1 */
{for(var i = 0, len = gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1.length ;i < len;++i) {
    gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1[i].getBehavior("Flippable").flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mortis"), gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1.length;i<l;++i) {
    if ( gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1[k] = gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1[i];
        ++k;
    }
}
gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1 */
{for(var i = 0, len = gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1.length ;i < len;++i) {
    gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1[i].getBehavior("Flippable").flipX(true);
}
}}

}


{


gdjs.Escena_32sin_32t_237tuloCode.eventsList2(runtimeScene);
}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Mortis"), gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1);
gdjs.copyArray(runtimeScene.getObjects("Pincho"), gdjs.Escena_32sin_32t_237tuloCode.GDPinchoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Escena_32sin_32t_237tuloCode.mapOfGDgdjs_9546Escena_959532sin_959532t_9595237tuloCode_9546GDMortisObjects1Objects, gdjs.Escena_32sin_32t_237tuloCode.mapOfGDgdjs_9546Escena_959532sin_959532t_9595237tuloCode_9546GDPinchoObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Escena sin título", false);
}{gdjs.evtTools.sound.playSound(runtimeScene, "Sonido de daño recibido muerte.wav", false, 100, 1);
}}

}


{


gdjs.Escena_32sin_32t_237tuloCode.eventsList3(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Llave"), gdjs.Escena_32sin_32t_237tuloCode.GDLlaveObjects1);
gdjs.copyArray(runtimeScene.getObjects("Mortis"), gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Escena_32sin_32t_237tuloCode.mapOfGDgdjs_9546Escena_959532sin_959532t_9595237tuloCode_9546GDMortisObjects1Objects, gdjs.Escena_32sin_32t_237tuloCode.mapOfGDgdjs_9546Escena_959532sin_959532t_9595237tuloCode_9546GDLlaveObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Escena_32sin_32t_237tuloCode.GDLlaveObjects1 */
{for(var i = 0, len = gdjs.Escena_32sin_32t_237tuloCode.GDLlaveObjects1.length ;i < len;++i) {
    gdjs.Escena_32sin_32t_237tuloCode.GDLlaveObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Sonido de llave recogida.wav", false, 100, 25);
}}

}


{


gdjs.Escena_32sin_32t_237tuloCode.eventsList4(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Antorcha"), gdjs.Escena_32sin_32t_237tuloCode.GDAntorchaObjects1);
gdjs.copyArray(runtimeScene.getObjects("Caballo"), gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Escena_32sin_32t_237tuloCode.mapOfGDgdjs_9546Escena_959532sin_959532t_9595237tuloCode_9546GDCaballoObjects1Objects, gdjs.Escena_32sin_32t_237tuloCode.mapOfGDgdjs_9546Escena_959532sin_959532t_9595237tuloCode_9546GDAntorchaObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1 */
{for(var i = 0, len = gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1.length ;i < len;++i) {
    gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1[i].returnVariable(gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1[i].getVariables().getFromIndex(0)).setString("izquierda");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Caballo"), gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1.length;i<l;++i) {
    if ( gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1[i].getVariableString(gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1[i].getVariables().getFromIndex(0)) == "izquierda" ) {
        isConditionTrue_0 = true;
        gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1[k] = gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1[i];
        ++k;
    }
}
gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1 */
{for(var i = 0, len = gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1.length ;i < len;++i) {
    gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1[i].addPolarForce(180, 25, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Antorcha2"), gdjs.Escena_32sin_32t_237tuloCode.GDAntorcha2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Caballo"), gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Escena_32sin_32t_237tuloCode.mapOfGDgdjs_9546Escena_959532sin_959532t_9595237tuloCode_9546GDCaballoObjects1Objects, gdjs.Escena_32sin_32t_237tuloCode.mapOfGDgdjs_9546Escena_959532sin_959532t_9595237tuloCode_9546GDAntorcha2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1 */
{for(var i = 0, len = gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1.length ;i < len;++i) {
    gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1[i].returnVariable(gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1[i].getVariables().getFromIndex(0)).setString("derecha");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Caballo"), gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1.length;i<l;++i) {
    if ( gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1[i].getVariableString(gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1[i].getVariables().getFromIndex(0)) == "derecha" ) {
        isConditionTrue_0 = true;
        gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1[k] = gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1[i];
        ++k;
    }
}
gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1 */
{for(var i = 0, len = gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1.length ;i < len;++i) {
    gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1[i].addPolarForce(0, 25, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Antorcha"), gdjs.Escena_32sin_32t_237tuloCode.GDAntorchaObjects1);
gdjs.copyArray(runtimeScene.getObjects("Caballo"), gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Escena_32sin_32t_237tuloCode.mapOfGDgdjs_9546Escena_959532sin_959532t_9595237tuloCode_9546GDCaballoObjects1Objects, gdjs.Escena_32sin_32t_237tuloCode.mapOfGDgdjs_9546Escena_959532sin_959532t_9595237tuloCode_9546GDAntorchaObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1 */
{for(var i = 0, len = gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1.length ;i < len;++i) {
    gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1[i].getBehavior("Flippable").flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Antorcha2"), gdjs.Escena_32sin_32t_237tuloCode.GDAntorcha2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Caballo"), gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Escena_32sin_32t_237tuloCode.mapOfGDgdjs_9546Escena_959532sin_959532t_9595237tuloCode_9546GDCaballoObjects1Objects, gdjs.Escena_32sin_32t_237tuloCode.mapOfGDgdjs_9546Escena_959532sin_959532t_9595237tuloCode_9546GDAntorcha2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1 */
{for(var i = 0, len = gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1.length ;i < len;++i) {
    gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1[i].getBehavior("Flippable").flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Caballo"), gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1);
gdjs.copyArray(runtimeScene.getObjects("Mortis"), gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Escena_32sin_32t_237tuloCode.mapOfGDgdjs_9546Escena_959532sin_959532t_9595237tuloCode_9546GDMortisObjects1Objects, gdjs.Escena_32sin_32t_237tuloCode.mapOfGDgdjs_9546Escena_959532sin_959532t_9595237tuloCode_9546GDCaballoObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Escena sin título", false);
}}

}


};

gdjs.Escena_32sin_32t_237tuloCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Escena_32sin_32t_237tuloCode.GDVentanaObjects1.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDVentanaObjects2.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDLlaveObjects1.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDLlaveObjects2.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDAntorchaObjects1.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDAntorchaObjects2.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDPeligroObjects1.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDPeligroObjects2.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDBoss_9595AzulObjects1.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDBoss_9595AzulObjects2.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects2.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDBoss_9595rojoObjects1.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDBoss_9595rojoObjects2.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDPinchoObjects1.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDPinchoObjects2.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDAzulejos_95951Objects1.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDAzulejos_95951Objects2.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDAzulejos_95952Objects1.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDAzulejos_95952Objects2.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDPlataformaObjects1.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDPlataformaObjects2.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects2.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDAntorcha2Objects1.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDAntorcha2Objects2.length = 0;

gdjs.Escena_32sin_32t_237tuloCode.eventsList5(runtimeScene);
gdjs.Escena_32sin_32t_237tuloCode.GDVentanaObjects1.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDVentanaObjects2.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDLlaveObjects1.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDLlaveObjects2.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDAntorchaObjects1.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDAntorchaObjects2.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDPeligroObjects1.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDPeligroObjects2.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDBoss_9595AzulObjects1.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDBoss_9595AzulObjects2.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects1.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDCaballoObjects2.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDBoss_9595rojoObjects1.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDBoss_9595rojoObjects2.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDPinchoObjects1.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDPinchoObjects2.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDAzulejos_95951Objects1.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDAzulejos_95951Objects2.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDAzulejos_95952Objects1.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDAzulejos_95952Objects2.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDPlataformaObjects1.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDPlataformaObjects2.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects1.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDMortisObjects2.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDAntorcha2Objects1.length = 0;
gdjs.Escena_32sin_32t_237tuloCode.GDAntorcha2Objects2.length = 0;


return;

}

gdjs['Escena_32sin_32t_237tuloCode'] = gdjs.Escena_32sin_32t_237tuloCode;
